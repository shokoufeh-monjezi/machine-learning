protoc --proto_path=. --js_out=import_style=commonjs,binary:. ./src/jarvis_proto/*.proto
