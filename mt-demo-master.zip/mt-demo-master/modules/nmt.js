/**
 * Copyright 2021 NVIDIA Corporation. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

require('dotenv').config({path: 'env.txt'});

var nmtProto = 'src/jarvis_proto/nmt.proto';
var protoRoot = __dirname + '/protos/';
var grpc = require('grpc');
var protoLoader = require('@grpc/proto-loader');
var Promise = require('bluebird');
const { request } = require('express');
var protoOptions = {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
    includeDirs: [protoRoot]
};

var nmtPkgDef = protoLoader.loadSync(nmtProto, protoOptions);
var nmt = grpc.loadPackageDefinition(nmtPkgDef).nvidia.riva.nmt;
var nmtClient = new nmt.RivaTranslate(process.env.NMT_API_URL, grpc.credentials.createInsecure());

function translate(text, sourceLang, targetLang) {
    // submit a jarvis NMT request
    req = {
        texts: [text.toLowerCase()],
        source_language: sourceLang,
        target_language: targetLang
    };

    return new Promise(function(resolve, reject) {
        nmtClient.TranslateText(req, function(err, resp_nmt) {
            if (err) {
                console.log('[Riva NMT] Error during NMT request (TranslateText): ' + err);
                reject(err);
            } else {
                // console.log(JSON.stringify(resp_nmt))
                resolve(resp_nmt.translations[0].translation);
            }
        });
    });
};

// translate('This morning I woke to the sounds of chickens. They were playing in my yard.', 'en', 'es')
// .then(result => {console.log(result)});

module.exports = {translate};
