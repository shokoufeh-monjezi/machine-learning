# Jarvis Machine Translation Demo

Voice-based live machine translation using NVIDIA Jarvis.

## Installation

Requires access to a running Jarvis server with a streaming speech recognition model such as Jasper.

First, clone the repository from Gitlab:

```
$ git clone https://gitlab-master.nvidia.com/cparisien/mt-demo.git
```

Install the required Node.js modules using the Node Package Manager (you might need to [install Node.js](https://nodejs.org/en/) itself if you haven't already):

```
$ cd mt-demo
$ npm install
```

To start the web service, from the `mt-demo`  directory on your server, run:

```
$ npm run start
```

This will start the Node.js application, and will start listening for connections.

## Using the service

Load the URL in a browser (Chrome works well; Firefox has issues with some network configurations). For best ASR results, a headset is recommended.

For example, if you're accessing the service from a computer within the local network, and it's hosted on a machine with the IP 192.168.2.10, then the URL would be https://192.168.2.10:8015/.