/**
 * Copyright 2020 NVIDIA Corporation. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

require('dotenv').config({path: 'env.txt'});

const socketIo = require('socket.io');
const fs = require('fs');
const https = require('https');
const cors = require('cors');
const express = require('express');
const session = require('express-session')({
    secret: "gVkYp3s6",
    resave: true,
    saveUninitialized: true,
    genid: function(req) {
        return uuid.v4();
    }
});
const uuid = require('uuid');
const sharedsession = require("express-socket.io-session");

const ASRPipe = require('./modules/asr');
const nmt = require('./modules/nmt');

const app = express();
const port = ( process.env.PORT );
const mt_supported_pairs = ( process.env.MT_LANG_PAIRS ).split(',');
const mt_rate_limit_ms = 500;
var last_mt_call_ms = 0;
var last_translation = '';
var server;
var sslkey = './certificates/key.pem';
var sslcert = './certificates/cert.pem';


/**
 * Set up Express Server with CORS and SocketIO
 */
function setupServer() {
    const ignoreRegex = RegExp(/^(.)\1{0,}(\.|\?)?\s*$/, 'i');
    var currentTime;

    // set up Express
    app.use(cors());
    app.use(express.static('web')); // ./web is the public dir for js, css, etc.
    app.use(session);
    app.get('/', function(req, res) {
         res.sendFile('./web/index.html', { root: __dirname });
    });
    server = https.createServer({
        key: fs.readFileSync(sslkey),
        cert: fs.readFileSync(sslcert)
    }, app);

    io = socketIo(server);
    io.use(sharedsession(session, {autoSave:true}));
    server.listen(port, () => {
        console.log('Running server on port %s', port);
    });

    // Listener, once the client connects to the server socket
    io.on('connect', (socket) => {
        console.log('Client connected from %s', socket.handshake.address);


        socket.on('start', (options) => {
            console.log('Client at %s started Riva service', socket.handshake.address);
            
            // Initialize Riva
            socket.handshake.session.langPair = 
                (mt_supported_pairs.includes(options.langPair) ? options.langPair.split('-') : null);
            socket.handshake.session.asr = new ASRPipe();
            socket.handshake.session.asr.setupASR(options.model, options.sampleRate);
            socket.handshake.session.asr.mainASR(function(result){
                if (result.transcript == undefined) {
                    return;
                }
                // Log the transcript to console, overwriting non-final results
                process.stdout.write(''.padEnd(process.stdout.columns, ' ') + '\r')
                if (!result.is_final) {
                    process.stdout.write('TRANSCRIPT: ' + result.transcript + '\r');
                } else {
                    process.stdout.write('TRANSCRIPT: ' + result.transcript + '\n');
                }
                socket.handshake.session.lastLineLength = result.transcript.length;

                // Don't return the short "Oo?" and "A?" kind of results
                if (ignoreRegex.test(result.transcript)) {
                    return;
                }

                currentTime = Date.now();
                if (socket.handshake.session.langPair) {
                    // Rate limiter: only call the translation service if it's a final transcript
                    // or if the wait period has passed
                    // if (result.is_final || (currentTime >= (last_mt_call_ms + mt_rate_limit_ms))) {
                    if (result.is_final) {
                        last_mt_call_ms = currentTime;
                        nmt.translate(result.transcript, socket.handshake.session.langPair[0],
                            socket.handshake.session.langPair[1])
                        .then(function(nmtResult) {
                            console.log(nmtResult);
                            result.sourceLang = socket.handshake.session.langPair[0];
                            result.translation = nmtResult;
                            result.targetLang = socket.handshake.session.langPair[1];
                            if (result.is_final) {
                                last_translation = ' ';
                            } else {
                                // last_translation = nmtResult;
                            }
                            socket.emit('transcript', result);  
                        }, function(error) {
                            console.log(error);
                        });
                    } else {
                        // otherwise sent back the most recent translation
                        result.sourceLang = socket.handshake.session.langPair[0];
                        result.translation = last_translation;
                        result.targetLang = socket.handshake.session.langPair[1];
                        socket.emit('transcript', result);  
                    }
                } else {
                    socket.emit('transcript', result);
                }
            });

        });

        socket.on('stop', (data) => {
            console.log('Client at %s stopped Riva service', socket.handshake.address);
            if (socket.handshake.session.asr) {
                socket.handshake.session.asr.recognizeStream.end();
            }
        });

        // incoming audio
        socket.on('audio_in', (data) => {
            if (socket.handshake.session.asr) {
                socket.handshake.session.asr.recognizeStream.write({audio_content: data});
            }
        });

        // change language pair for translation
        socket.on('lang_pair', (langPair) => {
            socket.handshake.session.langPair = 
                (mt_supported_pairs.includes(langPair) ? langPair.split('-') : null);
        });

        socket.on('disconnect', (reason) => {
            console.log('Client at %s disconnected. Reason: ', socket.handshake.address, reason);
        });
    });
};

process.on('SIGINT', function() {
    console.log("Caught interrupt signal, cleaning up");

    process.exit();
});

setupServer();