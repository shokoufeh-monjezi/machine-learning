/**
 * Copyright 2021 NVIDIA Corporation. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const id = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
const socketio = io();
const resampleWorker = './resampler.js';

var localStream;
var audioContext;
var sampleRate;
var rivaRunning = false;
var muted = false;
var socket = socketio.on('connect', function() {
    console.log('Socket connected to speech server');
});

var scrollToBottomTime = 500;
var latencyTimer;
var options = {model: 'none', langPair: 'none'};

var transcriptContainer;

// ---------------------------------------------------------------------------------------
// Latency tracking
// ---------------------------------------------------------------------------------------
class LatencyTimer {
    constructor() {
        this.startTimes = new Array();
        this.latencies = new Array();
    }

    start(data=null) {
        return this.startTimes.push({start: performance.now(), data: data}) - 1;
    }

    end(index) {
        if (index >= this.startTimes.length) {
            return 0;
        }
        var latency = Math.round(performance.now() - this.startTimes[index].start);
        this.latencies.push(latency);
        return {latency: latency, data: this.startTimes[index].data};
    }

    average() {
        const sum = this.latencies.reduce((a, b) => a + b, 0);
        return Math.round((sum / this.latencies.length) || 0);
    }
}

// ---------------------------------------------------------------------------------------
// Start Riva for streaming ASR
// ---------------------------------------------------------------------------------------
function startRivaService() {
    if (rivaRunning) {
        return;
    }
    options.sampleRate = sampleRate;
    socket.emit('start', options);

    // Start ASR streaming
    let audioInput = audio_context.createMediaStreamSource(localStream);

    // The stream-processor worklet node does the conversion from Float32 into 16-bit PCM
    audio_context.audioWorklet.addModule('./streamProcessor.js')
    .then(function() {
        var streamWorkletNode = new AudioWorkletNode(audio_context, 'stream-processor', {
            processorOptions: {
                sampleRate: sampleRate
            }
        });
        streamWorkletNode.port.onmessage = (event) => {
            // Send transformed PCM buffer to the server
            socket.emit('audio_in', event.data);
        };

        // connect stream to our worklet
        audioInput.connect(streamWorkletNode);
        // connect our worklet to the previous destination
        streamWorkletNode.connect(audio_context.destination);
    });

    rivaRunning = true;
}

// Transcription results streaming back from Riva
socket.on('transcript', function(result) {
    if (result.transcript == undefined) {
        return;
    }
    showTranscript(result);
});


// ---------------------------------------------------------------------------------------
// Shows transcript and translation if available
// ---------------------------------------------------------------------------------------
function showTranscript(result) {

    if (transcriptContainer == undefined) {
        // Create a new transcriptContainer to hold this round
        transcriptContainer = document.createElement('div');
        transcriptContainer.setAttribute('class', 'row');
        $("#transcription_area").append(transcriptContainer);
    }

    var sourceContainer = document.createElement('div');
    var translationContainer = document.createElement('div');

    function populateContainer(container, text) {
        container.setAttribute('class', 'transcript col');
        container.innerHTML = "<p>" + text + "</p>";
    }

    populateContainer(sourceContainer, result.transcript);
    transcriptContainer.innerHTML = '';
    transcriptContainer.appendChild(sourceContainer);
    if (result.translation) {
        sourceContainer.setAttribute('class', 'transcript col-sm-6');
        populateContainer(translationContainer, result.translation);
        translationContainer.setAttribute('class', 'transcript translation col-sm-6');
        transcriptContainer.appendChild(translationContainer);
    }
    
    $("#transcription_card").animate({scrollTop: 100000}, scrollToBottomTime);

    if (result.is_final) {
        transcriptContainer = undefined;
        $("#transcription_card").animate({scrollTop: 100000}, scrollToBottomTime);
    }

}

/**
 * Starts the request of the camera and microphone
 *
 * @param {Object} callbacks
 */
function requestLocalAudio(callbacks) {
   // Monkeypatch for crossbrowser getUserMedia
    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;

    // Request audio
    navigator.getUserMedia({ audio: true }, callbacks.success ,callbacks.error);
}


// ---------------------------------------------------------------------------------------
// On clicking the Transcription button, start Riva
// ---------------------------------------------------------------------------------------
$(document).on("click", "#riva-btn", function (e) {
    if (this.innerHTML == "Start") {
        startRiva();
    } else {
        stopRiva();
    }
});

function stopRiva() {
    audio_context.close();
    socket.emit('stop');
    socket.disconnect();
    $("#riva-btn").html('Start');
    rivaRunning = false;
}

function startRiva() {
    socket.connect();
    // socket.emit('start');

    requestLocalAudio({
        success: function(stream){
            localStream = stream;
            audio_context = new AudioContext();
            sampleRate = audio_context.sampleRate;
            console.log("Sample rate of local audio: " + sampleRate);
            startRivaService();
        },
        error: function(err){
            bootbox.alert("Cannot get access to your microphone.")
            .find(".bootbox-close-button").addClass("float-end");
            console.error(err);
        }
    });   

    $("#riva-btn").html('Stop');
}


function setAudioEnabled(enabled) {
    if (!localStream) return;
    for (const track of localStream.getAudioTracks()) {
        track.enabled = enabled;
    }
}

// ---------------------------------------------------------------------------------------
// On mute button, which should mute both call audio and Riva ASR
// ---------------------------------------------------------------------------------------
$(document).on("click", "#mute-btn", function (e) {
    if (!muted) {
        if($(this).hasClass("btn-primary")) {
            $("#mute-btn").removeClass("btn-primary").addClass("btn-danger");
            $("#mute-btn").tooltip('hide')
                .attr('data-original-title', 'Unmute')
                .tooltip('show');         
        }
        setAudioEnabled(false);
        muted = true;
    } else {
        if($(this).hasClass("btn-danger")) {
            $("#mute-btn").removeClass("btn-danger").addClass("btn-primary");               
            $("#mute-btn").tooltip('hide')
                .attr('data-original-title', 'Mute')
                .tooltip('show');         
        }
        setAudioEnabled(true);
        muted = false;
    }
});

// ---------------------------------------------------------------------------------------
// Click on text submit button
// ---------------------------------------------------------------------------------------
$(document).on("submit", "#input_form", function (e) {
    // Prevent reload of page after submitting of form
    e.preventDefault();
    let text = $('#input_field').val();
    console.log("text: " + text);

    socket.emit('nlp_request', {
        text: text,
        latencyIndex: latencyTimer.start({name: 'NLP request'})
    });
    // Erase input field
    $('#input_field').val("");
});

$(document).on("change", "#lang-select", function (e) {
    options['langPair'] = $("#lang-select").val();
    console.log("langPair: " + options['langPair']);
    socket.emit('lang_pair', options['langPair']);
});

$(document).on("change", "#model", function (e) {
    options['model'] = $("#model").val();
    console.log("model: " + options['model']);
    stopRiva();
    startRiva();
});
